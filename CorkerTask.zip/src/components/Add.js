import React, {useState} from "react";
import {Button, Form} from 'react-bootstrap';
import "bootstrap/dist/css/bootstrap.min.css";
import Restaurants from './restaurants.js'
import {v4 as uuid} from "uuid"
import {Link, useNavigate} from 'react-router-dom'

function Add(){
    const [name, setName] = useState("");
    const [address, setAddress] = useState("");
    const [pincode, setPincode] = useState("");
    const [mobile, setMobile] = useState("");
    const [email, setEmail] = useState("");
    const [website, setWebsite] = useState("");

    let history = useNavigate();

    const handleSubmit = (e) => {
        e.preventDefault();
        const ids = uuid();
        let uniqueId = ids.slice(0,8);

        let a = name,
        b = address,
        c = pincode,
        d = mobile,
        ea = email,
        f = website;

        Restaurants.push({id: uniqueId, Name : a, Address: b, Pincode: c, Mobile: d, Email: ea, Website: f  });
        history('/');


    }
    return <div>
        <Form className="d-grid gap-2 " style={{margin:"15rem"}}>
            <Form.Group className="mb-3" controlId="formName">
                <Form.Control type="text" required placeholder="Enter Name" onChange={(e) => setName(e.target.value)}>
                </Form.Control>
            </Form.Group>
            <Form.Group className="mb-3" controlId="formName">
                <Form.Control type="text" required placeholder="Enter Address" onChange={(e) => setAddress(e.target.value)}>
                </Form.Control>
            </Form.Group>
            <Form.Group className="mb-3" controlId="formName">
                <Form.Control type="number" required placeholder="Enter Pincode" onChange={(e) => setPincode(e.target.value)}>
                </Form.Control>
            </Form.Group>
            <Form.Group className="mb-3" controlId="formName">
                <Form.Control type="number" required placeholder="Enter Mobile" onChange={(e) => setMobile(e.target.value)}>
                </Form.Control>
            </Form.Group>
            <Form.Group className="mb-3" controlId="formName">
                <Form.Control type="text" required placeholder="Enter Email" onChange={(e) => setEmail(e.target.value)}>
                </Form.Control>
            </Form.Group>
            <Form.Group className="mb-3" controlId="formName">
                <Form.Control type="text" required placeholder="Enter Website" onChange={(e) => setWebsite(e.target.value)}>
                </Form.Control>
            </Form.Group>
            <Button onClick={(e) => handleSubmit(e)} type="submit">Submit</Button>
        </Form>
    </div>;
}

export default Add;