const Restaurants = [
    {
        Id:"1",
        Name:"dominos",
        Address:"plot-23, Nagpur",
        Pincode:"229394",
        Mobile:"7413656555",
        Email:"dominos@gmail.com",
        Website:"dominos.com"
    },
    {
        Id:"2",
        Name:"KFC",
        Address:"plot-43, Gurgaon",
        Pincode:"423394",
        Mobile:"7777525565",
        Email:"kfc@gmail.com",
        Website:"kfc.com"
    },
    {
        Id:"3",
        Name:"panino",
        Address:"plot-83, Mumbai",
        Pincode:"829334",
        Mobile:"6512456253",
        Email:"panino@gmail.com",
        Website:"panino.com"
    }
]

export default Restaurants;