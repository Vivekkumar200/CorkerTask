import React, { useEffect, useState } from "react";
import { Button, Form } from 'react-bootstrap';
import "bootstrap/dist/css/bootstrap.min.css";
import Restaurants from './restaurants.js'
import { v4 as uuid } from "uuid"
import { useNavigate } from 'react-router-dom'

function Edit() {
    const [name, setName] = useState("");
    const [address, setAddress] = useState("");
    const [pincode, setPincode] = useState("");
    const [mobile, setMobile] = useState("");
    const [email, setEmail] = useState("");
    const [website, setWebsite] = useState("");
    const [id, setId] = useState("");

    const history = useNavigate();

    useEffect(() => {
        const storedId = localStorage.getItem('Id');
        setId(storedId);
        const index = Restaurants.findIndex(item => item.id === storedId);
        if (index !== -1) {
            setName(Restaurants[index].Name);
            setAddress(Restaurants[index].Address);
            setPincode(Restaurants[index].Pincode);
            setMobile(Restaurants[index].Mobile);
            setEmail(Restaurants[index].Email);
            setWebsite(Restaurants[index].Website);
        }
    }, []);

    const handleSubmit = (e) => {
        e.preventDefault();
        const updatedRestaurant = {
            id,
            Name: name,
            Address: address,
            Pincode: pincode,
            Mobile: mobile,
            Email: email,
            Website: website
        };
        const updatedRestaurants = Restaurants.map(item => {
            if (item.id === id) {
                return updatedRestaurant;
            }
            return item;
        });
        // Update the Restaurants array with the updated restaurant
        // Here you would typically update your data source (e.g., database) as well
        // For now, just updating the local Restaurants array
        Restaurants.splice(0, Restaurants.length, ...updatedRestaurants);
        history('/');   
    }

    return (
        <div>
            <Form className="d-grid gap-2 " style={{ margin: "15rem" }}>
                <Form.Group className="mb-3" controlId="formName">
                    <Form.Control type="text" required placeholder="Enter Name" value={name} onChange={(e) => setName(e.target.value)} />
                </Form.Group>
                <Form.Group className="mb-3" controlId="formAddress">
                    <Form.Control type="text" required placeholder="Enter Address" value={address} onChange={(e) => setAddress(e.target.value)} />
                </Form.Group>
                <Form.Group className="mb-3" controlId="formPincode">
                    <Form.Control type="number" required placeholder="Enter Pincode" value={pincode} onChange={(e) => setPincode(e.target.value)} />
                </Form.Group>
                <Form.Group className="mb-3" controlId="formMobile">
                    <Form.Control type="number" required placeholder="Enter Mobile" value={mobile} onChange={(e) => setMobile(e.target.value)} />
                </Form.Group>
                <Form.Group className="mb-3" controlId="formEmail">
                    <Form.Control type="email" required placeholder="Enter Email" value={email} onChange={(e) => setEmail(e.target.value)} />
                </Form.Group>
                <Form.Group className="mb-3" controlId="formWebsite">
                    <Form.Control type="text" required placeholder="Enter Website" value={website} onChange={(e) => setWebsite(e.target.value)} />
                </Form.Group>
                <Button onClick={(e) => handleSubmit(e)} type="submit">Update</Button>
            </Form>
        </div>
    )
}

export default Edit;
