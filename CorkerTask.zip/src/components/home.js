import React, { Fragment } from "react";
import {Button, Table} from 'react-bootstrap';
import "bootstrap/dist/css/bootstrap.min.css";
import Restaurants from './restaurants.js'
import {Link, useNavigate} from 'react-router-dom'

function Home(){

    let history = useNavigate();

    const handleEdit = (id, name, address, pincode, mobile, email, website) =>{
        localStorage.getItem('Name',name);
        localStorage.getItem('Address',address);
        localStorage.getItem('Pincode',pincode);
        localStorage.getItem('Mobile',mobile);
        localStorage.getItem('Email',email);
        localStorage.getItem('Website',website);
        localStorage.getItem('Id',id);
    }

    const handleDelete = (id) => {
        var index = Restaurants.map(function(e) {
            return e.id
        }).indexOf(id);

        Restaurants.splice(index,1);
        history('/')
    }
    return (
        <Fragment>
            <div style={{margin:"10rem"}}>
                <Table stripped bordered hover size="sm">
                    <thead>
                        <tr>
                            <th>name</th>
                            <th>address</th>
                            <th>pincode</th>
                            <th>mobile</th>
                            <th>email</th>
                            <th>website</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            Restaurants && Restaurants.length > 0
                            ?
                            Restaurants.map((item) => {
                                return(
                                    <tr>
                                        <td>{item.Name}</td>
                                        <td>{item.Address}</td>
                                        <td>{item.Pincode}</td>
                                        <td>{item.Mobile}</td>
                                        <td>{item.Email}</td>
                                        <td>{item.Website}</td>
                                        <td>
                                            <Link to={'/edit'}>
                                            <Button onClick={() => handleEdit(item.Id, item.Name, item.Address, item.Pincode, item.Mobile, item.Email, item.Website) }>Edit</Button>
                                            </Link>
                                            &nbsp;
                                            <Button onClick={() => handleDelete(item.Id) }>Delete</Button>

                                        </td>
                                    </tr>
                                )
                            })
                            :
                            "No data available"
                        }
                    </tbody>
                </Table>
                <br>
                </br>
                <Link to={'/create'} className="d-grip gap-2">
                    <Button size="lg" >Create</Button>
                </Link>
            </div>
        </Fragment>
    )
}

export default Home;